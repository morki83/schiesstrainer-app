<script>
  import DisplayView from '$lib/components/DisplayView.svelte';
</script>

<main class="w-full h-screen">
  <DisplayView />
</main>
